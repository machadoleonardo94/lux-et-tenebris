G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-03-18T15:52:31-03:00*
G04 #@! TF.ProjectId,5mm_WS2812B_breakout,356d6d5f-5753-4323-9831-32425f627265,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-03-18 15:52:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.700000*%
%ADD11R,1.700000X1.700000*%
%ADD12C,1.800000*%
%ADD13RoundRect,0.450000X0.450000X0.450000X-0.450000X0.450000X-0.450000X-0.450000X0.450000X-0.450000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X0Y-2540000D03*
X0Y0D03*
D11*
X0Y2540000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D1*
X3074000Y724000D03*
X4598000Y-800000D03*
X6122000Y724000D03*
D13*
X7900000Y-800000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J2*
X11000000Y2540000D03*
D10*
X11000000Y0D03*
X11000000Y-2540000D03*
G04 #@! TD*
M02*
