#if !defined(CONSTANTS_DISPLAY)
#define CONSTANTS_DISPLAY

//* Paramethers for OLED display
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define SCREEN_ADDRESS 0x3C

#endif // CONSTANTS_DISPLAY
